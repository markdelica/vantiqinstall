// 1. Create a dynamic style block
var style = document.createElement('style');

// 2. Define the command center CSS
style.innerHTML = `
  /* Base state: Stealthy matte dark grey to blend with the data grid */
  .vantiqButton {
    background-color: #161b22 !important;
    color: #8b949e !important;
    border: 1px solid #30363d !important;
    font-family: 'IBM Plex Mono', monospace !important;
    font-weight: 600 !important;
    text-transform: uppercase !important;
    letter-spacing: 0.05em !important;
    border-radius: 4px !important;
    transition: all 0.2s ease-in-out !important;
    box-shadow: none !important;
    text-shadow: none !important;
  }

  /* Hover state: Lighter grey surface, bright text */
  .vantiqButton:hover {
    background-color: #21262d !important;
    color: #e6edf3 !important;
    border-color: #8b949e !important;
  }

  /* Focus state: The glowing neon blue accent when clicked */
  .vantiqButton:active,
  .vantiqButton:focus {
    background-color: rgba(88, 166, 255, 0.1) !important;
    color: #58a6ff !important;
    border-color: #58a6ff !important;
    box-shadow: 0 0 8px rgba(88, 166, 255, 0.3) !important;
    outline: none !important;
  }
`;

// 3. Inject it globally into the dashboard's <head>
document.head.appendChild(style);