var rec = page.data.selectedRow;
if (!rec) {
  alert("Select a row first");
  return;
}

var dropdown = client.getWidget("stateDropdown");
var selectedIndex = dropdown.boundValue;
var options = dropdown.enumeratedList;
var newState = options[selectedIndex - 1] ? options[selectedIndex - 1].label : null;

if (!newState) {
  alert("Select a state");
  return;
}

rec.current_state = newState;
delete rec._id;

client.upsert("com.smic.typ_SimControl_V2", rec, function(result) {
  //alert(rec.device_id + " → " + newState);
});



