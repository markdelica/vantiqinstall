console.log("POPUP PARAMS:", JSON.stringify(parameters));

setTimeout(function() {
  if (parameters && parameters.payload) {
    var payload = typeof parameters.payload === 'string' 
      ? JSON.parse(parameters.payload) 
      : parameters.payload;
    
    if (typeof dcimDdRender === 'function') {
      dcimDdRender(payload);
    } else {
      console.log("dcimDdRender not found yet");
    }
  } else {
    console.log("No payload in parameters");
  }
}, 500);