var ds = client.getDataStreamByName("pq_SimControlTable");
var p = new PagedQueryParameters();

p.whereClause = {
    device_group: "PACU"
};

client.modifyPagedQuery(ds, p);

