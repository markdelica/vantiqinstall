window._dcimCache = {};

window.dcimDdUpdate = function(data) {
  if (!data || !data.deviceId) return;
  window._dcimCache[data.deviceId] = data;
};

window._dcimOpenPopup = function(deviceId) {
  var payload = window._dcimCache[deviceId] || {};
  client.popupPage("DCIMDeviceDetail", "Device Detail", {
    deviceId: deviceId,
    payload: JSON.stringify(payload)
  });
};