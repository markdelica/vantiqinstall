var ds = client.getDataStreamByName("pq_SimControlTable");
var p = new PagedQueryParameters();

p.whereClause = {
    device_group: "UPS"
};

client.modifyPagedQuery(ds, p);

