//restartdatastream
var ds = client.getDataStreamByName("pq_SimControlTable");
if (ds) {
  ds.restart();
}