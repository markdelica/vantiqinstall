// ds_PACU_Raw — Data Arrived
if (!data) return;

var state = data.current_state || "normal";
var payload = null;

// Extract correct JSON payload based on current_state
if (state === "critical" && data.critical_json) {
  payload = typeof data.critical_json === "string" ? JSON.parse(data.critical_json) : data.critical_json;
} else if (state === "warning" && data.warning_json) {
  payload = typeof data.warning_json === "string" ? JSON.parse(data.warning_json) : data.warning_json;
} else if (data.normal_json) {
  payload = typeof data.normal_json === "string" ? JSON.parse(data.normal_json) : data.normal_json;
}

if (!payload) return;

// Use the bridge function defined in your HTML
if (typeof window.cl_pac_update === "function") {
  var update = {};
  
  // Mapping 'capacity_kw' from your payload to 'capacity' for the UI
  update[data.device_id] = {
    capacity: payload.capacity_kw, 
    status: payload.status
  };

  window.cl_pac_update(update);
}