// ds_UPS_Raw — Data Arrived
// Receives enriched event with all JSON columns + current_state

if (!data) return;

var state = data.current_state || "normal";
var payload = null;

if (state === "critical" && data.critical_json) {
  payload = typeof data.critical_json === "string" ? JSON.parse(data.critical_json) : data.critical_json;
} else if (state === "warning" && data.warning_json) {
  payload = typeof data.warning_json === "string" ? JSON.parse(data.warning_json) : data.warning_json;
} else if (data.normal_json) {
  payload = typeof data.normal_json === "string" ? JSON.parse(data.normal_json) : data.normal_json;
}

if (!payload) return;

if (typeof window.pw_ups_update === "function") {
  var update = {
    load: payload.load_pct,
    capacity: payload.capacity_kw,
    status: payload.status
  };

  if (data.device_id === "UPS_A") {
    window.pw_ups_update({ upsA: update });
  } else if (data.device_id === "UPS_B") {
    window.pw_ups_update({ upsB: update });
  }
}