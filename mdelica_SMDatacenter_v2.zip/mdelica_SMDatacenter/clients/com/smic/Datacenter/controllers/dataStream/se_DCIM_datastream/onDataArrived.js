console.log("DCM: --- New Event Arrived for:", data ? data.deviceId : "Unknown", "---");

if (!data || !data.derived) {
    console.log("DCM: Skipped - Missing 'derived' block.");
    return;
}

// ════════════════════════════════════════════
// POPUP BRIDGE
// ════════════════════════════════════════════
if (typeof parent.dcimDdUpdate === "function") {
    parent.dcimDdUpdate(data);
} else if (typeof window.dcimDdUpdate === "function") {
    window.dcimDdUpdate(data);
}

// UPS ROUTING
// ════════════════════════════════════════════
if (data.deviceType === "UPS") {
    if (typeof window.pw_ups_update === "function") {
        var upsUpdate = {
            load: data.derived.loadPct,
            capacity: data.derived.capacityKW,
            status: data.derived.status ? data.derived.status.toLowerCase() : "unknown"
        };
        if (data.deviceId === "UPS A") {
            window.pw_ups_update({ upsA: upsUpdate });
        } else if (data.deviceId === "UPS B") {
            window.pw_ups_update({ upsB: upsUpdate });
        }
    }
}

// ════════════════════════════════════════════
// PACU ROUTING
// ════════════════════════════════════════════
else if (data.deviceType === "PACU") {
    if (typeof window.cl_pac_update === "function") {
        var formattedId = data.deviceId.replace(" ", "_");
        var pacuPayload = {};
        pacuPayload[formattedId] = {
            capacity: data.derived.coolingCapacityKW,
            status: data.derived.status ? data.derived.status.toLowerCase() : "unknown"
        };
        window.cl_pac_update(pacuPayload);
        console.log("DCM: SUCCESS - Updated circle for", formattedId);
    }
}